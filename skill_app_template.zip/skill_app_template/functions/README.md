# Functions

Este template inclui 3 funções:
- `ping` (HTTP)
- `dailyNudge` (cron diário — placeholder)
- `weeklyLeaderboard` (cron semanal — placeholder)

Depois de configurar o Firebase:
```bash
firebase deploy --only functions
```
